<script>
	import { onMount } from 'svelte'
	
	import * as d3 from 'd3'
	
	import data from "./myData"
	
	const allStats = data.map(d => d.stats.length)
	
	console.log(allStats)
	const rangeOperations = d3.extent(allStats)
	console.log(rangeOperations)
	const operationR = d3.scaleLinear(rangeOperations, [30, 70])

	let mouseOverExpand = 1
	
	function groupStats({stats}){
		const grouped = d3.rollups(stats, (d) => d.length, (d) => d.operation);
		
		console.log(grouped)
		const pie = d3.pie().padAngle(0)
		const arcs = pie(grouped.map(d => d[1]))
		
		return [{ arcs: arcs, groups: grouped, highlight: 1}]
	}

	function getOperationColor(group){
		if(group[0] == "A") return d3.schemeSet1[2];
		if(group[0] == "M") return d3.schemeSet1[1];
		if(group[0] == "D") return d3.schemeSet1[0];
		return "grey"
	}
</script>

<svg width=100% height={data.length*100}>
	{#each data as commit, i (commit.hash)}
		<!-- <circle cx="50" cy={40 + 60*i} r={operationR(commit.stats.length)} fill={d3.interpolateSinebow(i/data.length)} stroke="white" /> -->
		<g stroke="white" stroke-width="0" transform="translate(50, {40 + 100*i})" >
			{#each groupStats(commit) as stat}
				{#each stat.arcs as arc, j}
					<path stroke-width="1px" d={d3.arc().innerRadius(10).cornerRadius(3).outerRadius(operationR(commit.stats.length))(arc)} fill={getOperationColor(stat.groups[j])} />
					<text dominant-baseline="central" text-anchor="middle" fill="white" x={d3.arc().cornerRadius(10).innerRadius(0).outerRadius(operationR(commit.stats.length)).centroid(arc)[0]} y={d3.arc().innerRadius(0).outerRadius(operationR(commit.stats.length)*stat.highlight).centroid(arc)[1]}>{stat.groups[j][0]}</text>
				{/each}
			{/each}
		</g>
		<text color="currentColor" fill="white" x={60 + operationR(commit.stats.length)} y={45 + 100*i} style="font-weight:600;"> #{commit.hashAbbrev} - {commit.subject} </text>
		{#each groupStats(commit) as stat}
			<text color="currentColor" fill="white" x={60 + operationR(commit.stats.length)} y={45 + 100*i} dx="0em" dy="1.25em"  style="font-weight:300;">{stat.groups.map(s=> ` ${s[0]}: ${s[1]}`)}</text>
		{/each}
	{/each}
</svg>