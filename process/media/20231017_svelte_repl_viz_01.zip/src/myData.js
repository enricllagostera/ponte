export default [
  {
    "refs": ["HEAD", "master", "origin/master", "origin/HEAD"],
    "hash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
    "hashAbbrev": "fd73828",
    "tree": "b9b353b783d5bbedbc60180e2a55fe10a14e44b2",
    "treeAbbrev": "b9b353b",
    "parents": ["1f8672a8f1c68559fa6db49e7ff291e1e073fc11"],
    "parentsAbbrev": ["1f8672a"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1667503366000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1667503366000
    },
    "subject": "Fixed typo",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "process/journal.md" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\.gitignore",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\README.md",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62"
      },
      {
        "name": "_config.yml",
        "rel": "_config.yml",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\_config.yml",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62"
      },
      {
        "name": "assets",
        "rel": "assets",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\assets",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "css",
            "rel": "assets\\css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\assets\\css",
            "selected": false,
            "children": [
              {
                "name": "style.css",
                "rel": "assets\\css\\style.css",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\assets\\css\\style.css",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\images",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\index.html",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62"
      },
      {
        "name": "info",
        "rel": "info",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\info",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "README.md",
            "rel": "info\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\info\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "info\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\info\\images",
            "selected": false,
            "children": [
              {
                "name": "it-is-as-if-you-were-making-love-banner.png",
                "rel": "info\\images\\it-is-as-if-you-were-making-love-banner.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\info\\images\\it-is-as-if-you-were-making-love-banner.png",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\js\\script.js",
            "selected": false
          }
        ]
      },
      {
        "name": "press",
        "rel": "press",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "README.md",
            "rel": "press\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "press\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images",
            "selected": false,
            "children": [
              {
                "name": "about.png",
                "rel": "press\\images\\about.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\about.png",
                "selected": false
              },
              {
                "name": "desktop.png",
                "rel": "press\\images\\desktop.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\desktop.png",
                "selected": false
              },
              {
                "name": "petite-mort.png",
                "rel": "press\\images\\petite-mort.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\petite-mort.png",
                "selected": false
              },
              {
                "name": "play.png",
                "rel": "press\\images\\play.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\play.png",
                "selected": false
              },
              {
                "name": "slow-down.png",
                "rel": "press\\images\\slow-down.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\slow-down.png",
                "selected": false
              },
              {
                "name": "title.png",
                "rel": "press\\images\\title.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\press\\images\\title.png",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "process",
        "rel": "process",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process",
        "selected": false,
        "commitHash": "fd73828a573723f00c7ac1445bd8a855a6980f62",
        "children": [
          {
            "name": "README.md",
            "rel": "process\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "process\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images",
            "selected": false,
            "children": [
              {
                "name": "2018-03-24-notes.png",
                "rel": "process\\images\\2018-03-24-notes.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\2018-03-24-notes.png",
                "selected": false
              },
              {
                "name": "2018-03-30-notes.png",
                "rel": "process\\images\\2018-03-30-notes.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\2018-03-30-notes.png",
                "selected": false
              },
              {
                "name": "about-text.png",
                "rel": "process\\images\\about-text.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\about-text.png",
                "selected": false
              },
              {
                "name": "horizontal-slider-original-labels.png",
                "rel": "process\\images\\horizontal-slider-original-labels.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\horizontal-slider-original-labels.png",
                "selected": false
              },
              {
                "name": "horizontal-slider-relabelled.png",
                "rel": "process\\images\\horizontal-slider-relabelled.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\horizontal-slider-relabelled.png",
                "selected": false
              },
              {
                "name": "love-ui-1.png",
                "rel": "process\\images\\love-ui-1.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\love-ui-1.png",
                "selected": false
              },
              {
                "name": "love-ui-2.png",
                "rel": "process\\images\\love-ui-2.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\love-ui-2.png",
                "selected": false
              },
              {
                "name": "love-ui-3.png",
                "rel": "process\\images\\love-ui-3.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\love-ui-3.png",
                "selected": false
              },
              {
                "name": "love-ui-4.png",
                "rel": "process\\images\\love-ui-4.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\love-ui-4.png",
                "selected": false
              },
              {
                "name": "love-ui-5.png",
                "rel": "process\\images\\love-ui-5.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\love-ui-5.png",
                "selected": false
              },
              {
                "name": "original-game-idea-in-things.png",
                "rel": "process\\images\\original-game-idea-in-things.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\original-game-idea-in-things.png",
                "selected": false
              },
              {
                "name": "sepe-blurred.png",
                "rel": "process\\images\\sepe-blurred.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\sepe-blurred.png",
                "selected": false
              },
              {
                "name": "splash-screen.png",
                "rel": "process\\images\\splash-screen.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\splash-screen.png",
                "selected": false
              },
              {
                "name": "vertical-slider.png",
                "rel": "process\\images\\vertical-slider.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\images\\vertical-slider.png",
                "selected": false
              }
            ]
          },
          {
            "name": "journal.md",
            "rel": "process\\journal.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\journal.md",
            "selected": false
          },
          {
            "name": "manifesto.md",
            "rel": "process\\manifesto.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\manifesto.md",
            "selected": false
          },
          {
            "name": "related-work.md",
            "rel": "process\\related-work.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\related-work.md",
            "selected": false
          },
          {
            "name": "to-do.md",
            "rel": "process\\to-do.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fd73828a573723f00c7ac1445bd8a855a6980f62\\process\\to-do.md",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
    "hashAbbrev": "1f8672a",
    "tree": "7f1e94cb2f7b57a1f457d0121edb19b8afd1b5b7",
    "treeAbbrev": "7f1e94c",
    "parents": ["eb6a4c4ede4a210c2377d562101bf311e72cb787"],
    "parentsAbbrev": ["eb6a4c4"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1658242618000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1658242618000
    },
    "subject": "Updating to new web standard",
    "body": "",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "README.md" },
      { "operation": "A", "path_original": "_config.yml" },
      { "operation": "A", "path_original": "assets/css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "info/README.md" },
      {
        "operation": "A",
        "path_original": "info/images/it-is-as-if-you-were-making-love-banner.png"
      },
      { "operation": "A", "path_original": "press/README.md" },
      { "operation": "A", "path_original": "press/images/about.png" },
      { "operation": "A", "path_original": "press/images/desktop.png" },
      { "operation": "A", "path_original": "press/images/petite-mort.png" },
      { "operation": "A", "path_original": "press/images/play.png" },
      { "operation": "A", "path_original": "press/images/slow-down.png" },
      { "operation": "A", "path_original": "press/images/title.png" },
      { "operation": "A", "path_original": "process/README.md" },
      {
        "operation": "A",
        "path_original": "process/images/2018-03-24-notes.png"
      },
      {
        "operation": "A",
        "path_original": "process/images/2018-03-30-notes.png"
      },
      { "operation": "A", "path_original": "process/images/about-text.png" },
      {
        "operation": "A",
        "path_original": "process/images/horizontal-slider-original-labels.png"
      },
      {
        "operation": "A",
        "path_original": "process/images/horizontal-slider-relabelled.png"
      },
      { "operation": "A", "path_original": "process/images/love-ui-1.png" },
      { "operation": "A", "path_original": "process/images/love-ui-2.png" },
      { "operation": "A", "path_original": "process/images/love-ui-3.png" },
      { "operation": "A", "path_original": "process/images/love-ui-4.png" },
      { "operation": "A", "path_original": "process/images/love-ui-5.png" },
      {
        "operation": "A",
        "path_original": "process/images/original-game-idea-in-things.png"
      },
      { "operation": "A", "path_original": "process/images/sepe-blurred.png" },
      { "operation": "A", "path_original": "process/images/splash-screen.png" },
      {
        "operation": "A",
        "path_original": "process/images/vertical-slider.png"
      },
      { "operation": "A", "path_original": "process/journal.md" },
      { "operation": "A", "path_original": "process/manifesto.md" },
      { "operation": "A", "path_original": "process/related-work.md" },
      { "operation": "A", "path_original": "process/to-do.md" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\.gitignore",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\README.md",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11"
      },
      {
        "name": "_config.yml",
        "rel": "_config.yml",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\_config.yml",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11"
      },
      {
        "name": "assets",
        "rel": "assets",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\assets",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "css",
            "rel": "assets\\css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\assets\\css",
            "selected": false,
            "children": [
              {
                "name": "style.css",
                "rel": "assets\\css\\style.css",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\assets\\css\\style.css",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\images",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\index.html",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11"
      },
      {
        "name": "info",
        "rel": "info",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\info",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "README.md",
            "rel": "info\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\info\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "info\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\info\\images",
            "selected": false,
            "children": [
              {
                "name": "it-is-as-if-you-were-making-love-banner.png",
                "rel": "info\\images\\it-is-as-if-you-were-making-love-banner.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\info\\images\\it-is-as-if-you-were-making-love-banner.png",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\js\\script.js",
            "selected": false
          }
        ]
      },
      {
        "name": "press",
        "rel": "press",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "README.md",
            "rel": "press\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "press\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images",
            "selected": false,
            "children": [
              {
                "name": "about.png",
                "rel": "press\\images\\about.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\about.png",
                "selected": false
              },
              {
                "name": "desktop.png",
                "rel": "press\\images\\desktop.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\desktop.png",
                "selected": false
              },
              {
                "name": "petite-mort.png",
                "rel": "press\\images\\petite-mort.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\petite-mort.png",
                "selected": false
              },
              {
                "name": "play.png",
                "rel": "press\\images\\play.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\play.png",
                "selected": false
              },
              {
                "name": "slow-down.png",
                "rel": "press\\images\\slow-down.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\slow-down.png",
                "selected": false
              },
              {
                "name": "title.png",
                "rel": "press\\images\\title.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\press\\images\\title.png",
                "selected": false
              }
            ]
          }
        ]
      },
      {
        "name": "process",
        "rel": "process",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process",
        "selected": false,
        "commitHash": "1f8672a8f1c68559fa6db49e7ff291e1e073fc11",
        "children": [
          {
            "name": "README.md",
            "rel": "process\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\README.md",
            "selected": false
          },
          {
            "name": "images",
            "rel": "process\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images",
            "selected": false,
            "children": [
              {
                "name": "2018-03-24-notes.png",
                "rel": "process\\images\\2018-03-24-notes.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\2018-03-24-notes.png",
                "selected": false
              },
              {
                "name": "2018-03-30-notes.png",
                "rel": "process\\images\\2018-03-30-notes.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\2018-03-30-notes.png",
                "selected": false
              },
              {
                "name": "about-text.png",
                "rel": "process\\images\\about-text.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\about-text.png",
                "selected": false
              },
              {
                "name": "horizontal-slider-original-labels.png",
                "rel": "process\\images\\horizontal-slider-original-labels.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\horizontal-slider-original-labels.png",
                "selected": false
              },
              {
                "name": "horizontal-slider-relabelled.png",
                "rel": "process\\images\\horizontal-slider-relabelled.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\horizontal-slider-relabelled.png",
                "selected": false
              },
              {
                "name": "love-ui-1.png",
                "rel": "process\\images\\love-ui-1.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\love-ui-1.png",
                "selected": false
              },
              {
                "name": "love-ui-2.png",
                "rel": "process\\images\\love-ui-2.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\love-ui-2.png",
                "selected": false
              },
              {
                "name": "love-ui-3.png",
                "rel": "process\\images\\love-ui-3.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\love-ui-3.png",
                "selected": false
              },
              {
                "name": "love-ui-4.png",
                "rel": "process\\images\\love-ui-4.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\love-ui-4.png",
                "selected": false
              },
              {
                "name": "love-ui-5.png",
                "rel": "process\\images\\love-ui-5.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\love-ui-5.png",
                "selected": false
              },
              {
                "name": "original-game-idea-in-things.png",
                "rel": "process\\images\\original-game-idea-in-things.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\original-game-idea-in-things.png",
                "selected": false
              },
              {
                "name": "sepe-blurred.png",
                "rel": "process\\images\\sepe-blurred.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\sepe-blurred.png",
                "selected": false
              },
              {
                "name": "splash-screen.png",
                "rel": "process\\images\\splash-screen.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\splash-screen.png",
                "selected": false
              },
              {
                "name": "vertical-slider.png",
                "rel": "process\\images\\vertical-slider.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\images\\vertical-slider.png",
                "selected": false
              }
            ]
          },
          {
            "name": "journal.md",
            "rel": "process\\journal.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\journal.md",
            "selected": false
          },
          {
            "name": "manifesto.md",
            "rel": "process\\manifesto.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\manifesto.md",
            "selected": false
          },
          {
            "name": "related-work.md",
            "rel": "process\\related-work.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\related-work.md",
            "selected": false
          },
          {
            "name": "to-do.md",
            "rel": "process\\to-do.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1f8672a8f1c68559fa6db49e7ff291e1e073fc11\\process\\to-do.md",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
    "hashAbbrev": "eb6a4c4",
    "tree": "07908d8a585291e1607d4d58d6903830ba6e2ee3",
    "treeAbbrev": "07908d8",
    "parents": ["5fe6c583efabaafed02e41f8daad732a975cddc1"],
    "parentsAbbrev": ["5fe6c58"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1654882943000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1654882943000
    },
    "subject": "Added info dir",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "A", "path_original": "info/README.md" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\.gitignore",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\README.md",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\images",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\index.html",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787"
      },
      {
        "name": "info",
        "rel": "info",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\info",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
        "children": [
          {
            "name": "README.md",
            "rel": "info\\README.md",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\info\\README.md",
            "selected": false
          }
        ]
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js",
        "selected": false,
        "commitHash": "eb6a4c4ede4a210c2377d562101bf311e72cb787",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eb6a4c4ede4a210c2377d562101bf311e72cb787\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "5fe6c583efabaafed02e41f8daad732a975cddc1",
    "hashAbbrev": "5fe6c58",
    "tree": "f6c4355dd7e4941ac383dc0bb59030ae43125fa7",
    "treeAbbrev": "f6c4355",
    "parents": ["9970613568702650c0808d157a3408316314893c"],
    "parentsAbbrev": ["9970613"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529938195000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529938195000
    },
    "subject": "Added tracking",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "index.html" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\.gitignore",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\README.md",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\images",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\index.html",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js",
        "selected": false,
        "commitHash": "5fe6c583efabaafed02e41f8daad732a975cddc1",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5fe6c583efabaafed02e41f8daad732a975cddc1\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "9970613568702650c0808d157a3408316314893c",
    "hashAbbrev": "9970613",
    "tree": "ad9d733775ea671e56be813bcf69abb86b3dc8ae",
    "treeAbbrev": "ad9d733",
    "parents": ["9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63"],
    "parentsAbbrev": ["9afa42f"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529937890000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529937890000
    },
    "subject": "Updated readme",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "README.md" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\.gitignore",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\README.md",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\images",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\index.html",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js",
        "selected": false,
        "commitHash": "9970613568702650c0808d157a3408316314893c",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9970613568702650c0808d157a3408316314893c\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63",
    "hashAbbrev": "9afa42f",
    "tree": "e0e30d456042bb8cb4990d14d4a85fdb61e016bf",
    "treeAbbrev": "e0e30d4",
    "parents": ["30fe551fd6da26b3aacf15a9bdd118fb62dafd5c"],
    "parentsAbbrev": ["30fe551"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529926530000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529926530000
    },
    "subject": "Updated README",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "README.md" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\.gitignore",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\README.md",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\images",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\index.html",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js",
        "selected": false,
        "commitHash": "9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\9afa42fa38ec0141e37d02ff3ff42eeac1c6ee63\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c",
    "hashAbbrev": "30fe551",
    "tree": "14d5d0bc99839b026d231d5a7be1ba22720078e7",
    "treeAbbrev": "14d5d0b",
    "parents": ["92c7fce502e80a3533e1c9f7df21dc1b99ccf782"],
    "parentsAbbrev": ["92c7fce"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529880965000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529880965000
    },
    "subject": "Fixed petite mort title for game over dialog",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\.gitignore",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\README.md",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\images",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\index.html",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js",
        "selected": false,
        "commitHash": "30fe551fd6da26b3aacf15a9bdd118fb62dafd5c",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\30fe551fd6da26b3aacf15a9bdd118fb62dafd5c\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782",
    "hashAbbrev": "92c7fce",
    "tree": "3e6a0a0e2c01554c71092453324514c53f98d331",
    "treeAbbrev": "3e6a0a0",
    "parents": ["c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf"],
    "parentsAbbrev": ["c4a18cc"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529804243000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529804243000
    },
    "subject": "Edited about text, removed positive feedback and input dialog boxes",
    "body": "# About text\n\nJust some tweaks to try to really nail the language. Think it's pretty much there now.\n\n# Dialog boxes\n\nDecided after some testing with J+M that they're too intrusive when they show up while you're being successful. The positive message is just a distraction and breaks the flow and you already know you're doing well from the other messages. The text-input dialog is a funny thing and worth exploring, but in this game it feels like it's too much or pulling to hard in a different direction. I'll use it another time.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "js/data.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\.gitignore",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\README.md",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\images",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\index.html",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js",
        "selected": false,
        "commitHash": "92c7fce502e80a3533e1c9f7df21dc1b99ccf782",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\92c7fce502e80a3533e1c9f7df21dc1b99ccf782\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf",
    "hashAbbrev": "c4a18cc",
    "tree": "2d559a9742d705ea2219e0463104fc289abb456e",
    "treeAbbrev": "2d559a9",
    "parents": ["a8657075cd55673f93fc225e6707d3441aac0214"],
    "parentsAbbrev": ["a865707"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529701302000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529701302000
    },
    "subject": "Made some small adjustments to widths (and to the about text) to fit the game on the iPhone SE screen size, which is the lowest I plan to support",
    "body": "",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "js/data.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\.gitignore",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\README.md",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\images",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\index.html",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js",
        "selected": false,
        "commitHash": "c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c4a18cced05d6fb7f08a1ad6d0b2a05ee778c7bf\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "a8657075cd55673f93fc225e6707d3441aac0214",
    "hashAbbrev": "a865707",
    "tree": "37f770364e72244210cf30fe0bdf351cc2d34bb0",
    "treeAbbrev": "37f7703",
    "parents": ["0484e25bcd28d9a922c926724189e27588f764f8"],
    "parentsAbbrev": ["0484e25"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529700731000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529700731000
    },
    "subject": "The game over dialog title is 'petite mort' (ha ha, because it's a terminal error) and the pre-orgasm asks you to 'push my button' (ha ha, euphemisms)",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\.gitignore",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\README.md",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\images",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\index.html",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js",
        "selected": false,
        "commitHash": "a8657075cd55673f93fc225e6707d3441aac0214",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a8657075cd55673f93fc225e6707d3441aac0214\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "0484e25bcd28d9a922c926724189e27588f764f8",
    "hashAbbrev": "0484e25",
    "tree": "c808f2a7c3985d5e96e845b41b45df6aaeb4095e",
    "treeAbbrev": "c808f2a",
    "parents": ["f899265d31ae76db89bde3aa3dba4c62c4825fcc"],
    "parentsAbbrev": ["f899265"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529694403000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529694403000
    },
    "subject": "Wrote a better game over, moved and rewrote a bunch of code to try to force iOS to play my sounds (specifically the orgasm cacophony), added shake effect for a trembling pre-orgasm moment that quite pleasing",
    "body": "# Game over message\n\nGame over is now an \"arousal overflow\" which I find pleasing. It's an ending dialog based around a screenshot I found of a Windows-based buffer overrun error. It works nicely as a deadpan ending, with the app itself still orgasming all over the place in the background. When you dismiss the message, the whole thing shuts down. I actually only did it this way in order to be able to turn the sounds off! But it works well.\n\n# Pre-orgasm\n\nSame thing as above. iOS sound restrictions require me to induce a click from the user so that I can turn sounds/on off. Notably if I want to set the orgasm sounds in motion, there needs to be a specific user input (a click), so now there's a trembling pre-orgasm dialog (may need better language) that sets it off when you say 'ok'. It feels a little bit teasing/s&m in a way? Maybe it should say \"May I?\" Huh.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "js/data.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\.gitignore",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\README.md",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\images",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\index.html",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js",
        "selected": false,
        "commitHash": "0484e25bcd28d9a922c926724189e27588f764f8",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\0484e25bcd28d9a922c926724189e27588f764f8\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc",
    "hashAbbrev": "f899265",
    "tree": "f479a3f89ba177a2c5aa4d1f698875400d5a464c",
    "treeAbbrev": "f479a3f",
    "parents": ["da065984e2616163fef002118fce97a4d8474371"],
    "parentsAbbrev": ["da06598"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529675494000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529675494000
    },
    "subject": "Code rewrite to move selection results into a timer set off in slide to attempt to get more iOS sounds working",
    "body": "# Why?\n\niOS only allows sounds to play when they're triggered by a user event. But I need sounds to play on a delay from user input (e.g. selection is acknolwedged a little bit after you select to create the effect of needing to be purposeful). I get the impression that iOS will play a sound triggered by a timeout that's set inside an event handler. It also results in kind of cleaner code I thiiiiink? Anyway, I did this to test my hypothesis and to thus get the feedback 'click' on iOS.",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\.gitignore",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\README.md",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\images",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\index.html",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js",
        "selected": false,
        "commitHash": "f899265d31ae76db89bde3aa3dba4c62c4825fcc",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\f899265d31ae76db89bde3aa3dba4c62c4825fcc\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "da065984e2616163fef002118fce97a4d8474371",
    "hashAbbrev": "da06598",
    "tree": "704f7b9c0be38e66884e37ce7e74f2231e2833e0",
    "treeAbbrev": "704f7b9",
    "parents": ["eda5e66043bb579126bd1ad9174d177e4d7481b8"],
    "parentsAbbrev": ["eda5e66"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529673750000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529673750000
    },
    "subject": "Made about text smaller to fit vertically (on my phone), fixed typo, trying a 'no scroll on mobile' approach (position fixed for body and html)",
    "body": "# All about mobile\n\nI really want the game to work well enough on mobile that somebody who chooses to play it that way doesn't view it as utterly broken. I already know that on the iPhone SE (and lower I guess) it doesn't display well because the width of the display is 20px to narrow, leading to overflow. The game is still playable in that scenario, though (no vital UI is blocked), so I'm pretty tempted to not give a shit.\n\nHowever it would be nice to eliminate the frustrations of the way iOS hides and shows the browser chrome depending on scrolling, so I'm trying to kill scrolling with A Tip From The Internet. Worked in Chrome emulator, but that means exactly jack shit of course. Pushing mostly to test it.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "js/data.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\.gitignore",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\README.md",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\images",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\index.html",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js",
        "selected": false,
        "commitHash": "da065984e2616163fef002118fce97a4d8474371",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\da065984e2616163fef002118fce97a4d8474371\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "eda5e66043bb579126bd1ad9174d177e4d7481b8",
    "hashAbbrev": "eda5e66",
    "tree": "9766fd9c3a8922d5dd7dd6da2c5c6c9ecab8b5f0",
    "treeAbbrev": "9766fd9",
    "parents": ["43783da025bb873734df81cb073383437baeb4a8"],
    "parentsAbbrev": ["43783da"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529632637000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529632637000
    },
    "subject": "Put the arousal stroke back to correct value for testing.",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\.gitignore",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\README.md",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\images",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\index.html",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js",
        "selected": false,
        "commitHash": "eda5e66043bb579126bd1ad9174d177e4d7481b8",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\eda5e66043bb579126bd1ad9174d177e4d7481b8\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "43783da025bb873734df81cb073383437baeb4a8",
    "hashAbbrev": "43783da",
    "tree": "1eccb98260bfddbc391bfbb8bdd55631c07c9701",
    "treeAbbrev": "1eccb98",
    "parents": ["c1fe467d33ccd130b9d5aa98a98bfb1d6822c733"],
    "parentsAbbrev": ["c1fe467"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529632505000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529632505000
    },
    "subject": "Created a separate data file for text, rewrote all texts, adjusted stroke difficulty, made multiple games possible",
    "body": "# Rewriting\n\nPursuant to the large amount of soul-searching about language alongside good feedback from a number of sources (notably Jim, Mary, and Jess), I tried my hand at a serious rewrite of the language in the game to set a more 'accurate' tone to the idea behind the software. I think it's significantly better, but it needs to be tested. (I won't lie, though, I'm feeling pretty fatigued by this at this point, so can't guarantee I've genuinely done a good job.)\n\n# Stroke difficulty\n\nJim and Mary both had trouble with the fast strokes, so I made them easier - it's not really about being 'good at it', just about distinguishing fast and slow.\n\n# Multiple games\n\nThe icons don't vanish from the desktop and clicking the app icon resets the game so you can play again right away if you want. That kind of accessibility makes a lot more sense to me in the better-defined context of the game. It _is_ in service to the human (even as they service it).",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "index.html" },
      { "operation": "A", "path_original": "js/data.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\.gitignore",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\README.md",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\images",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\index.html",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js",
        "selected": false,
        "commitHash": "43783da025bb873734df81cb073383437baeb4a8",
        "children": [
          {
            "name": "data.js",
            "rel": "js\\data.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\data.js",
            "selected": false
          },
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\43783da025bb873734df81cb073383437baeb4a8\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733",
    "hashAbbrev": "c1fe467",
    "tree": "0cb136a846ac16ee2d7dbe2ca397cdd99fab0564",
    "treeAbbrev": "0cb136a",
    "parents": ["fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a"],
    "parentsAbbrev": ["fbc8aa4"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529097781000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1529097781000
    },
    "subject": "Relabelled slider to go from -5 to 0 to 5",
    "body": "# Relabelling\n\nAs discussed in my journal etc., the idea here is to make the slider symmetric rather than have an obvious 'base' and 'tip' that might imply penis. The symmetry perhaps makes it more like other erotic body parts and thus hopefully pulls focus from any penis-y feelings that the movement of the slider probably still evokes...",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\.gitignore",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\README.md",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\images",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\index.html",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js",
        "selected": false,
        "commitHash": "c1fe467d33ccd130b9d5aa98a98bfb1d6822c733",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c1fe467d33ccd130b9d5aa98a98bfb1d6822c733\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a",
    "hashAbbrev": "fbc8aa4",
    "tree": "788f55b14c9b40864f5ca5bb8c16f96420e9aba7",
    "treeAbbrev": "788f55b",
    "parents": ["3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7"],
    "parentsAbbrev": ["3b4d33b"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528987839000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528987839000
    },
    "subject": "Built a horizontal slider prototype",
    "body": "# But why?\n\nI'm in conversation with Jim and Mary (my parents) about the gendered nature of the vertical slider. Had the important experience of Mary pointing out that sliding the vertical slider has different connotations for her as a woman. I'm trying to walk this line of the interface evoking the biological kind of sex and drawing on the eroticism of that, but without wanting to slide into the 'masturbating a male interface' chasm because that will really alter the experience for a lot of people and not in a way that I think is the right direction for the overall idea behind this project. Specifically, if I want it to feel like 'pleasuring a computer because pleasuring other people (or things?) is a pleasure' then it needs particular kinds of inflections. If it feels like a chore, or a gross patriarchical or gender normative thing, then it's going to lose that sense.\n\nSo I've made the slider horizontal as a test to run it by people. It maintains the important (I think) quality of still being a real-time and continuous form of input (unlike other UI elements) which I find important or at least interesting for the sexual nature of things. But by not being vertical it's at least not immediately like an erect penis? I mean, who ever thought I'd be writing about things like this in a git repository commit message? Not me. But it's also kiiiind of amazing I haven't explicitly addressed this much until the 'end' of the project. We'll see whether this issue ends up requiring more radical redesigns, but it's becoming clear that I suspect can't just go ahead with the vertical... argh.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\.gitignore",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\README.md",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\images",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\index.html",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js",
        "selected": false,
        "commitHash": "fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fbc8aa486a9c6a1be605ee0bf0cf683a9b6f727a\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7",
    "hashAbbrev": "3b4d33b",
    "tree": "672d2399309fe02f7e4bbe7d1a7a5d12ef973cef",
    "treeAbbrev": "672d239",
    "parents": ["7c4f6269b7db1a1ab413badb023126bbcf9996d5"],
    "parentsAbbrev": ["7c4f626"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528891428000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528891428000
    },
    "subject": "Added readme, readme icon, new app icon",
    "body": "# Readme\n\nAs with the Work game, I wanted to have some kind of diegetic text that explains the nature of the application and situated the speculative play aspect of things for anyone who might be interested. Again it's a kind of readme.txt you can check out before playing, totally optional. I mirrored the style of the Work text and I think the argument made is pretty reasonable (I mean makes sense, obviously). It was a real challenge getting a text that would be short enough to fit on a mobile screen and the iPhone 5/SE still elludes me (for the entire UI acutally, not just the readme).\n\n# Icons\n\nI used the standard windows \"text file\" icon for the readme, unsurprisingly. Once I had that in, the app icon looked a bit weird and not so nice, just because I'd repainted it rather than using a pure icon. As such I went back to original icons and found a stand-alone hand and a computer with what kind of looks like fireworks on its screen (maybe for a screensaver or something?). I combined those in Pixen to end up with a hand kind of caressing the computer which errupts in fireworks? At least that's what I see.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "A", "path_original": "images/app-icon.png" },
      { "operation": "D", "path_original": "images/icon.png" },
      { "operation": "A", "path_original": "images/readme-icon.png" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\.gitignore",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\README.md",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\images",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7",
        "children": [
          {
            "name": "app-icon.png",
            "rel": "images\\app-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\images\\app-icon.png",
            "selected": false
          },
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\images\\heart.png",
            "selected": false
          },
          {
            "name": "readme-icon.png",
            "rel": "images\\readme-icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\images\\readme-icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\index.html",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js",
        "selected": false,
        "commitHash": "3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3b4d33bafc1d13b35484f7d89a95fe5466fbc8a7\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5",
    "hashAbbrev": "7c4f626",
    "tree": "c537bf91d09b4d1004c0f4c0b7e267d36fee44df",
    "treeAbbrev": "c537bf9",
    "parents": ["ce1dff5a4e6745a357c4091d94b1dbb4a03983c6"],
    "parentsAbbrev": ["ce1dff5"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528839082000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528839082000
    },
    "subject": "Added the orgasm",
    "body": "# Consider the orgasm\n\nHoo boy, that was a flurry of programming. Integrated pretty much what I said I would in the todos so that the game now actually has an ending. So when you reach an arousal level of 1.0 you get a kind of 'spasming' of the various UI elements that 'makes sense' for - sounds, the slider setting, the slider target, the radio buttons, and the messages field. I think there's some work to be done in terms of tuning it, particularly the idea of the cooldown, which right now feels not ramped quite right - I think we need to dwell in the end of the cooldown longer, those final twitches. But overall the orgasm state is... honestly it's pretty good.\n\n# Consider the post-orgasm\n\nRight now once the orgasm is done the whole app shuts down, returning to an earlier idea I had that it would be kind of 'selfish' about things and just leave on completion. I mostly did this because... it's easier right now and it feels like a complete narrative moment? So it shuts down and then there's a \"Thanks for playing!\" dialog that pops up, and when you close that it's the shutdown sound and that's that, no ability to restart the game or anything.\n\nI'm wondering about\n\n- Do I implement the version where you can make a date to meet again?\n- Do I implement the idea of the UI having a cooldown between sessions so you can't just reload it and go again? (Is this interesting in this context, or just me wanting to be Robert Yang?)\n\n# Language\n\nThe language needs a buuuuunch of work mon fr�re. I know that and you know that.",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\.gitignore",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\README.md",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\images",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\index.html",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js",
        "selected": false,
        "commitHash": "7c4f6269b7db1a1ab413badb023126bbcf9996d5",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\7c4f6269b7db1a1ab413badb023126bbcf9996d5\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6",
    "hashAbbrev": "ce1dff5",
    "tree": "ea699064b8b71173b92de1b2377fd6a46c4c0f26",
    "treeAbbrev": "ea69906",
    "parents": ["08dc92b35d3dce5a2efb422f65d90c11dd9819b9"],
    "parentsAbbrev": ["08dc92b"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528831142000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528831142000
    },
    "subject": "Added feedback messages, feedback dialogs, arousal entropy",
    "body": "# Feedback messages and dialogs\n\nThe game now gives feedback for poor strokes (too fast, too slow) and good strokes (on target). Feedback can be either an update in the message field (including a flash so you actually check it), or a dialog box if it's particularly important (if you have multiple bad strokes or if you're doing well over time). It feels like it makes a big difference to the experience and the flashing message box actually works really well for foregrounding that UI element and helping the player pay attention to it. Who knew that a tried and tested form of UI design would be effective? Eh? Not me.\n\nI have concerns/thoughts about tuning the language, and there's of course tuning in terms of the frequency of the dialog based feedback in particular since it's pretty disruptive. Though they at least don't interact with the stroke timer, so you don't get penalised in that way (and notably it doesn't affect entropy).\n\n# Arousal entropy\n\nAfter thinking I wouldn't have it in the game, I've added the idea that arousal diminishes over time if you just leave the system alone. There's a threshold and then it starts to decline, based on the current stroke time. So if you just stroke and then don't do anything, then eventually arousal drops toward zero. But there's room for a little breather at least. Note that this conflicts with an idea I had that there would be an instruction to just leave the slider completely alone as an erotic act, but I think maybe that's too complex at this point, too 'hard' for the user to do? I'll think about it.",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\.gitignore",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\README.md",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\images",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\index.html",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js",
        "selected": false,
        "commitHash": "ce1dff5a4e6745a357c4091d94b1dbb4a03983c6",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\ce1dff5a4e6745a357c4091d94b1dbb4a03983c6\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9",
    "hashAbbrev": "08dc92b",
    "tree": "3b19daddc55183013432a456b318a62e34ee6b78",
    "treeAbbrev": "3b19dad",
    "parents": ["e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad"],
    "parentsAbbrev": ["e1d627f"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528823693000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528823693000
    },
    "subject": "Added text input request with random requests and hints, added positive feedback phrases (but not implemented yet)",
    "body": "# Text input\n\nCreated an array of text input requests designed to help the player feel more involved by 'expressing' themselves in words. \"I want you\", \"I need you\" and so on. Did some of the obvious regular expressions stuff to give the player _some_ leeway with how they type it in, but also like the idea that they have to type _exactly_ the right response. If you get it wrong twice the system will just tell you what to time, which is also funny, like someone guiding your hand - \"ugh, just do it like this!\"\n\n# Positive feedback\n\nAdded a bunch of phrases that can be popped up at random intervals to emphasise the sensuality of the experience for the computer side (or at least its feigned engagement at that level). Have to continue to think about the language here as right now it's _really_ suggestive, like \"keep sliding me\"... need to think about whether I want that or whether it should be a little less obviously kind of human. Should it use metaphors and language from an operating system/piece of software? It's a question.",
    "notes": "",
    "stats": [{ "operation": "M", "path_original": "js/script.js" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\.gitignore",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\README.md",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\images",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\index.html",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js",
        "selected": false,
        "commitHash": "08dc92b35d3dce5a2efb422f65d90c11dd9819b9",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\08dc92b35d3dce5a2efb422f65d90c11dd9819b9\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad",
    "hashAbbrev": "e1d627f",
    "tree": "f66f3b28dfd9a5e12688d3ad94cf135d927a6f7e",
    "treeAbbrev": "f66f3b2",
    "parents": ["3eb488f22b6babebb117828384cfb2cedffbc85d"],
    "parentsAbbrev": ["3eb488f"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528820920000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528820920000
    },
    "subject": "Added breathing sounds",
    "body": "# Breathing\n\nI added breathing sounds because breathing is a pretty important part of making something feel organic, and of course because breathing is a big part of representing exertion and, in this case, arousal. It's a way to make the game sexier outside the obvious confines of the user-interface which by its nature needs to be pretty blank. I am, however, still using a Windows sound as the breathing - it's called ir_begin (presumaby played when an ifra-red thing is about to transmit, all very erotic in itself). By playing with the pitch and pacing and volume of the sound I think I'm able to get something that sounds fairly close to breathing, which is neat. By speeding it up and pitching it up etc., there's a definite sense (I think) of increased arousal from the interface... it takes it somewhere much more intimate and gives you some actual feedback on how things are going!",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "audio/ir_begin.wav" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\.gitignore",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\README.md",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_begin.wav",
            "rel": "audio\\ir_begin.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\ir_begin.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\images",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\index.html",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js",
        "selected": false,
        "commitHash": "e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\e1d627f3ac31ed5732ea9cf953b3e2c69ff951ad\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "3eb488f22b6babebb117828384cfb2cedffbc85d",
    "hashAbbrev": "3eb488f",
    "tree": "02620ba062c09a93e4fe473953569114c7e14d82",
    "treeAbbrev": "02620ba",
    "parents": ["66f1cc74197039b2453177e3a51b88671de25e9d"],
    "parentsAbbrev": ["66f1cc7"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528503935000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528503935000
    },
    "subject": "Added tracking of stroke speed, changed to a single \"messages\" panel",
    "body": "# Stroke speed\n\nAdded the idea of fast/slow/indifferent and timing how long each stroke is. Track number of 'bad strokes'. Set up to be able to give feedback ot the player based on all of this.\n\n# Message panel\n\nStarted to feel like it was redundant having the two panels. And 'messages' is a really fun name for an output.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\.gitignore",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\README.md",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\images",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\index.html",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js",
        "selected": false,
        "commitHash": "3eb488f22b6babebb117828384cfb2cedffbc85d",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3eb488f22b6babebb117828384cfb2cedffbc85d\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "66f1cc74197039b2453177e3a51b88671de25e9d",
    "hashAbbrev": "66f1cc7",
    "tree": "b667de13420622c722324f062f0faa2383ad8ec6",
    "treeAbbrev": "b667de1",
    "parents": ["6ff7aab2590c0552bf4c7a6408920b031e952eda"],
    "parentsAbbrev": ["6ff7aab"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528489562000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528489562000
    },
    "subject": "Added more controlled stroke ranges and strokes required, stroke timer, rearranged code, added title splash",
    "body": "# Controlled strokes\n\nNow have stroke ranges and numbers set up with arrays so that it's easier to tune to specific stroke formats and numbers, it works well I think and makes more sense in terms of being able to control the experience the player's having - there are particular kinds of strokes that are sexier, I think, than others (e.g. 0 to 10 is hotter than 1 to 7, say). I mean, this is getting pretty weird, but I think it's true. Likewise, the number of strokes required is a finesse thing - you particularly don't want too few I think, though perhaps occasionally it's good.\n\n# Stroke timer\n\nNot doing anything with it yet, but the code now counts frames between selections so you know how long a stroke took. I was impressed by how it felt like something even to do that. And actually this makes me wonder whether actually displaying the current average stroke time or something makes some sense? Will think about it. Could be part of the feedback? Like \"slow down, you're going at X-strokes-per-second\"? This also points me at another problem which is how likely the player is to pay attention to the speed feedback. Should that be more front and centre with the slider? I feel like I'm gradually obviating the instruction panel though? Need to think about that more...\n\n# Title splash\n\nWanted to have one of those retro 'card style' splash screens while the application loads. Ended up using Microsoft Windows 6.0 as a reference point, which has mostly text and then a clip-arty drawing of a pen (e.g. a kind of indexical sign?). Created something roughly like that but with a picture of a human heart (pixellated). Originally used a really amazing, bloody pig's heart an artist had taken a photo of, which looked very good, but for copyright purposes went across to a royalty free image which works well too. Definitely adds a lot to the idea of this as 'real' software, so I think that's a big win. It's fun.\n\nNote that in using the image of a heart as an organ I'm sort of gesturing toward this idea that the software is machine-made in some way and that they've made a slight error in picking the wrong kind of heart. It's not clear to me how far down that road I want to think (like 'what would the AI do/design?'), but I find it amusing, and it signals something 'weird' is going on from the beginning. I wonder now whether the icon for the application should be the/a heart too?",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "A", "path_original": "images/heart.png" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\.gitignore",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\README.md",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\images",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d",
        "children": [
          {
            "name": "heart.png",
            "rel": "images\\heart.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\images\\heart.png",
            "selected": false
          },
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\index.html",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js",
        "selected": false,
        "commitHash": "66f1cc74197039b2453177e3a51b88671de25e9d",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\66f1cc74197039b2453177e3a51b88671de25e9d\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "6ff7aab2590c0552bf4c7a6408920b031e952eda",
    "hashAbbrev": "6ff7aab",
    "tree": "7eabda855d9f486d47155fd6f7c5a4ecec2d0561",
    "treeAbbrev": "7eabda8",
    "parents": ["c432ffb12c8d732c894cf9b7091981e3d7102b06"],
    "parentsAbbrev": ["c432ffb"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528396005000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528396005000
    },
    "subject": "Added mood music radio boxes and function",
    "body": "",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" },
      { "operation": "D", "path_original": "js/ui-generators.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\.gitignore",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\README.md",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\images",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda",
        "children": [
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\index.html",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js",
        "selected": false,
        "commitHash": "6ff7aab2590c0552bf4c7a6408920b031e952eda",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6ff7aab2590c0552bf4c7a6408920b031e952eda\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "c432ffb12c8d732c894cf9b7091981e3d7102b06",
    "hashAbbrev": "c432ffb",
    "tree": "ee4d986e09597e95b7ca49f24004baa9295bf6ee",
    "treeAbbrev": "ee4d986",
    "parents": ["fc8dd33bc66735585b9c123089def80b99267912"],
    "parentsAbbrev": ["fc8dd33"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528394650000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528394650000
    },
    "subject": "Added icon that launches the application, improved slider positioning and dialog positioning",
    "body": "# Icon\n\nThe game now starts as an icon on an empty 'desktop'. The current icon is taken from some semi-random set of Windows 95 (ish?) icons, it's an edited version of a human hand holding up a printer. I removed the paper coming out of the printer so now it looks like (to me) a human hand holding a computer, which is kind of a nice 'loving' image perhaps? I'm not 100% happy with the aspect ratio of the image, because it's a bit flat and doesn't quite read as much like an application icon as I want. I can fiddle with that.\n\nThe icon-launching version did turn out to be necessary because iOS won't let you play sounds without some kind of input event. So now clicking the icon is the thing that starts everything rolling and from there it should just work.\n\n# Positioning\n\nNothing so interesting, just making things work better.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "A", "path_original": "images/icon.png" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\.gitignore",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\README.md",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "images",
        "rel": "images",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\images",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06",
        "children": [
          {
            "name": "icon.png",
            "rel": "images\\icon.png",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\images\\icon.png",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\index.html",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js",
        "selected": false,
        "commitHash": "c432ffb12c8d732c894cf9b7091981e3d7102b06",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c432ffb12c8d732c894cf9b7091981e3d7102b06\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "fc8dd33bc66735585b9c123089def80b99267912",
    "hashAbbrev": "fc8dd33",
    "tree": "c0bb9acd039db178b3c811a44431eb0c59de9f8d",
    "treeAbbrev": "c0bb9ac",
    "parents": ["3476e92bc22cdabc78188f2f774bb440e15427a6"],
    "parentsAbbrev": ["3476e92"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528386706000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528386706000
    },
    "subject": "Added sound effects, music and a embryonic title screen",
    "body": "# Sound\n\nTook the first step of inserting a bunch of Windows 2000 sounds into the game in 'appropriate' situations. Some of them match the _Work_ soundscape, such as the dialog-opening sound and the correct/incorrect button sounds. But there are new ones like a click for acknowledging the slider when to the right location, a notification sound for when the range shifts and/or you make progress on the progress bar, a startup sound that plays while a title card fades in.\n\n# Music\n\nCreated some smooth-ish jazz on [Wolfram Tones](http://tones.wolfram.com/generate/) and have that playing after the title when the application itself opens. It doesn't sound _quite_ right yet, but I think it makes a decent amount of sense. I guess you could have a button/check-box that enableds or disables 'mood music'? Might be pretty funny. Default it to off. Yeah that makes better sense. Here we are, designing in a commit message, just like MDMA taught us. Getting the music to loop clearly required installing [howler.js](https://howlerjs.com/) which seems to do a really nice job of it, god bless other people.\n\n# Title screen\n\nJust an idea for now, but as a consequence of having a startup sound you need an actual startup. Earlier I'd thought about maybe presenting a desktop icon for the application the user would start up (and still could need to do this pending issues around sound triggering on iOS for example?), but for now I'm going with the way shitty Windows programs load with that awkward application card that appears in the middle of your screen while the application loads. So I've got a kind of simulated version of that for now that fades in to the startup sound, then goes away when the app window pops up.",
    "notes": "",
    "stats": [
      { "operation": "D", "path_original": "audio/breath-mono.wav" },
      { "operation": "A", "path_original": "audio/chimes.wav" },
      { "operation": "A", "path_original": "audio/chord.wav" },
      { "operation": "A", "path_original": "audio/ding.wav" },
      { "operation": "A", "path_original": "audio/ir_inter.wav" },
      { "operation": "A", "path_original": "audio/music.wav" },
      { "operation": "A", "path_original": "audio/notify.wav" },
      { "operation": "A", "path_original": "audio/shutdown.wav" },
      { "operation": "A", "path_original": "audio/start.wav" },
      { "operation": "A", "path_original": "audio/startup.wav" },
      { "operation": "A", "path_original": "audio/tada.wav" },
      { "operation": "D", "path_original": "audio/tone.wav" },
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "D", "path_original": "js/flocking-all.min.js" },
      { "operation": "A", "path_original": "js/howler.core.min.js" },
      { "operation": "D", "path_original": "js/lodash.min.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\.gitignore",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\README.md",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912",
        "children": [
          {
            "name": "chimes.wav",
            "rel": "audio\\chimes.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\chimes.wav",
            "selected": false
          },
          {
            "name": "chord.wav",
            "rel": "audio\\chord.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\chord.wav",
            "selected": false
          },
          {
            "name": "ding.wav",
            "rel": "audio\\ding.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\ding.wav",
            "selected": false
          },
          {
            "name": "ir_inter.wav",
            "rel": "audio\\ir_inter.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\ir_inter.wav",
            "selected": false
          },
          {
            "name": "music.wav",
            "rel": "audio\\music.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\music.wav",
            "selected": false
          },
          {
            "name": "notify.wav",
            "rel": "audio\\notify.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\notify.wav",
            "selected": false
          },
          {
            "name": "shutdown.wav",
            "rel": "audio\\shutdown.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\shutdown.wav",
            "selected": false
          },
          {
            "name": "start.wav",
            "rel": "audio\\start.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\start.wav",
            "selected": false
          },
          {
            "name": "startup.wav",
            "rel": "audio\\startup.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\startup.wav",
            "selected": false
          },
          {
            "name": "tada.wav",
            "rel": "audio\\tada.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\audio\\tada.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\index.html",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js",
        "selected": false,
        "commitHash": "fc8dd33bc66735585b9c123089def80b99267912",
        "children": [
          {
            "name": "howler.core.min.js",
            "rel": "js\\howler.core.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\howler.core.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\fc8dd33bc66735585b9c123089def80b99267912\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "3476e92bc22cdabc78188f2f774bb440e15427a6",
    "hashAbbrev": "3476e92",
    "tree": "755c05b88acede43bbae63d06b862a22e99060d4",
    "treeAbbrev": "755c05b",
    "parents": ["175173f8648e98e1b55f618de5f87809ee52a6ab"],
    "parentsAbbrev": ["175173f"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528316148000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528316148000
    },
    "subject": "Did initial work to make it cross-platform, added modal 'tell me you love me' dialog",
    "body": "# Cross platform\n\nBasically just shifted it over to a set pixel width instead of using viewport. It's hacky but it does look pretty acceptable across platforms now and it's exact. I'll have to test it on a real phone, and for some reason it's not centring on an iPhone SE (in emulation), but largely it seems pretty effective and it would be a huge relief not to have to fuck around with this too much.\n\n# Modal talk dialog\n\nAdded a basic dialog box that pops up over the interface and interrupts everything (including sending a fake mouseup to the slider so you can't keep or resume sliding) and asks you, for now, to write \"I love you\", though of course I'll want that to be minimally procedural. I like the idea of an interrupt like this to break the flow of things, and it's a key opportunity to have the player express themselves in a different way. It doesn't contribute to arousal but is rather a way to have a different form of input that commits you to the experience more...",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "js/script.js" },
      { "operation": "M", "path_original": "js/ui-generators.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\.gitignore",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\README.md",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\audio",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\index.html",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js",
        "selected": false,
        "commitHash": "3476e92bc22cdabc78188f2f774bb440e15427a6",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "lodash.min.js",
            "rel": "js\\lodash.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\lodash.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\3476e92bc22cdabc78188f2f774bb440e15427a6\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "175173f8648e98e1b55f618de5f87809ee52a6ab",
    "hashAbbrev": "175173f",
    "tree": "07bba86d76f5decb7fa2387f0a41a91ab1a36356",
    "treeAbbrev": "07bba86",
    "parents": ["b7c24613005e17b7845ca867513e8cb45012483f"],
    "parentsAbbrev": ["b7c2461"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528313677000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528313677000
    },
    "subject": "Added a minimum number of frames to hold selection for it to count, fiddled with target formatting",
    "body": "# Selection timer\n\nTrying to avoid the situation where someone can just blinding slide the slider up and down and not care about what it wants. By setting a minimum number of frames you have to hold the slider in position, you can't do that any more. By making that number of frames quite low, you can maintain a good fluidity of motion if you want to, and this allows for the idea of being too fast as well as too slow - it feels less plodding. Especially if I increase the number of desired strokes to a higher range so you can get into a good rhythm for a while before it requests something new. Sexy?\n\n# Target formatting\n\nHad a conversation with Jonathan over coffee about how to show the target. It's kind of painful, but you also kind of accept whatever it is. I added a border to the selected one which kind of feels better somehow, less arbitrary? Could even be that it doesn't need anything more than an outline, not even a background colour. Hard to say, but I'm fairly happy with it for now.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\.gitignore",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\README.md",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\audio",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\index.html",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js",
        "selected": false,
        "commitHash": "175173f8648e98e1b55f618de5f87809ee52a6ab",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "lodash.min.js",
            "rel": "js\\lodash.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\lodash.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\175173f8648e98e1b55f618de5f87809ee52a6ab\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "b7c24613005e17b7845ca867513e8cb45012483f",
    "hashAbbrev": "b7c2461",
    "tree": "2461de0d3b7902d6a0de5d985ea9feadd63205dc",
    "treeAbbrev": "2461de0",
    "parents": ["cedebc40c5baf55b6badf9e41d350b491aaa388c"],
    "parentsAbbrev": ["cedebc4"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528300725000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528300725000
    },
    "subject": "Shifted to a set of labeled UI elements, gave up on indicating target on slider itself",
    "body": "# UI change\n\nAfter a conversation with Rilla about the affordances and meanings of the UI, trying to embrace win95 specificity even more by having the UI more explicitly divided into different elements/panels. So now there's a slider, then a 'instruction' text panel, then an 'output' text panel, then a progress bar, all labelled explicitly. I've tested out the basics of how it feels to watch the instruction while sliding the slider and it seems more or less okay - a bit worried it could break the flow too much, but we'll just have to see further down the line.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\.gitignore",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\README.md",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\audio",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\index.html",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js",
        "selected": false,
        "commitHash": "b7c24613005e17b7845ca867513e8cb45012483f",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "lodash.min.js",
            "rel": "js\\lodash.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\lodash.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b7c24613005e17b7845ca867513e8cb45012483f\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "cedebc40c5baf55b6badf9e41d350b491aaa388c",
    "hashAbbrev": "cedebc4",
    "tree": "6d097c7cac4b5a0b73db3e9d2c8e1fb83ccbd43e",
    "treeAbbrev": "6d097c7",
    "parents": ["83faea945ee8dab1d5b8a33229f02dada2300a27"],
    "parentsAbbrev": ["83faea9"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528293293000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1528293293000
    },
    "subject": "Created 'app version' with the UI inside a window, styled instructions/feedback, added progress bar",
    "body": "# App version\n\nAs per the design journal, I've been feeling like the slider on its own in the centre of the screen looks too isolated and too close to a potential 'slickness' that seems to reflect a more contemporary style and thus to evoke associations/connotations/expectations I don't want. By moving the slider and other UI inside a typical win95 style window, I think that assumption gets broken pretty effectively. I actually quite like the observation that the title in the menu bar gets abbreviated with an ellipsis on mobile, that has a realness to it that I appreciate.\n\n# Styled instructions/feedback\n\nIn keeping with this aesthetic change, I gave the instructions a bevelled border in the same way as the slider, mimicking the win95 approach. Made the background of the text field grey because I feel like that indicates text that is output from the computer, that could conceivably change, but that cannot be edited? Not sure where that assumption is coming from, particularly the idea that it can indicate something dynamic. Log files maybe?\n\n# Progress bar\n\nAdded a progress bar officially and again styled it as per win95 (they have a white background, garishly). The progress bar is kind of a nice symbol of the simplification of this game, moving away from ambiguity and the sexiness of not knowing to certainty and the sexiness of knowing. Makes my life easier and it's good to have that symbolised right there in the UI in case I forget!",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" },
      { "operation": "M", "path_original": "js/ui-generators.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\.gitignore",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\README.md",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\audio",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\index.html",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js",
        "selected": false,
        "commitHash": "cedebc40c5baf55b6badf9e41d350b491aaa388c",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "lodash.min.js",
            "rel": "js\\lodash.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\lodash.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\cedebc40c5baf55b6badf9e41d350b491aaa388c\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "83faea945ee8dab1d5b8a33229f02dada2300a27",
    "hashAbbrev": "83faea9",
    "tree": "44b238009a18119b66c295fc2583a87e7ec499d9",
    "treeAbbrev": "44b2380",
    "parents": ["c31ac63c0ae795e1bb25481d682d3c6941e6c2ec"],
    "parentsAbbrev": ["c31ac63"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1525379517000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1525379517000
    },
    "subject": "Moved to Windows 95 styling, added dialog generation from Work game to test, moved to 10 settings instead of 100, added local versions of libraries",
    "body": "? There's a distinctly different feeling involved with the win95\naesthetic. I'm not 100% sure that it makes total sense to me yet, but\nit's approaching something that's looking more like it has a personality\nand some kind of grasp on a reality. It's not so clear that this\naesthetic 'make sense' for this application, but even just to position\nit as a proper sequel/co-existent of It is as if you were doing work\nfeels like a valuable addition.\n\n? In moving back to the \"only 10 settings\" version of the slider the\nexperience is of course much more janky and unsmooth... but I'm\nbeginning to wonder whether there's something nice about that. It brings\nthe computer back in a way, less evocative of a biological pleasuring\nand more of a computer pleasuring with ten unit settings. Makes more\n'sense' perhaps in terms of this balancing act between wanting it to be\nactually sexy and wanting it to be actually computational feeling. Hard\nline to walk.\n\n? Confirmed that when a dialog pops up it doesn't steal focus from the\nslider, which means it's possible to bring up dialogs during play\nwithout ruining the user experience. Pondering the idea of dialogs that\naren't dismissable and just represent an output for the system to\nindicate how things are going. They can disappear on their own over time\nand the player could move them out of the way. Have to consider, though,\nhow this would play out in mobile? The dialogs may be too dominant in\nthat scenario.\n\n? Continue to lose serious time in CSS styling woes with these kind of\novercomplicated libraries to emulate uncomplicated UI setups. There's\nprobably some delicious comical irony in there, but it doesn't register\nas fun while I'm doing it.",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "css/LICENSE.txt" },
      {
        "operation": "A",
        "path_original": "css/images/ui-icons_000_256x240.png"
      },
      {
        "operation": "A",
        "path_original": "css/images/ui-icons_222_256x240.png"
      },
      {
        "operation": "A",
        "path_original": "css/images/ui-icons_444444_256x240.png"
      },
      {
        "operation": "A",
        "path_original": "css/images/ui-icons_cc0000_256x240.png"
      },
      {
        "operation": "A",
        "path_original": "css/images/ui-icons_fff_256x240.png"
      },
      { "operation": "A", "path_original": "css/index.html" },
      { "operation": "A", "path_original": "css/jquery-ui.min.css" },
      { "operation": "A", "path_original": "css/jquery-ui.structure.min.css" },
      { "operation": "A", "path_original": "css/jquery-ui.theme.min.css" },
      { "operation": "A", "path_original": "css/package.json" },
      { "operation": "A", "path_original": "css/style-old.css" },
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "A", "path_original": "js/jquery-ui.min.js" },
      { "operation": "A", "path_original": "js/jquery.min.js" },
      { "operation": "A", "path_original": "js/lodash.min.js" },
      { "operation": "M", "path_original": "js/script.js" },
      { "operation": "A", "path_original": "js/ui-generators.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\.gitignore",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\README.md",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\audio",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27",
        "children": [
          {
            "name": "LICENSE.txt",
            "rel": "css\\LICENSE.txt",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\LICENSE.txt",
            "selected": false
          },
          {
            "name": "images",
            "rel": "css\\images",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images",
            "selected": false,
            "children": [
              {
                "name": "ui-icons_000_256x240.png",
                "rel": "css\\images\\ui-icons_000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images\\ui-icons_000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_222_256x240.png",
                "rel": "css\\images\\ui-icons_222_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images\\ui-icons_222_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_444444_256x240.png",
                "rel": "css\\images\\ui-icons_444444_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images\\ui-icons_444444_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_cc0000_256x240.png",
                "rel": "css\\images\\ui-icons_cc0000_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images\\ui-icons_cc0000_256x240.png",
                "selected": false
              },
              {
                "name": "ui-icons_fff_256x240.png",
                "rel": "css\\images\\ui-icons_fff_256x240.png",
                "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\images\\ui-icons_fff_256x240.png",
                "selected": false
              }
            ]
          },
          {
            "name": "index.html",
            "rel": "css\\index.html",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\index.html",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "jquery-ui.min.css",
            "rel": "css\\jquery-ui.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\jquery-ui.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.structure.min.css",
            "rel": "css\\jquery-ui.structure.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\jquery-ui.structure.min.css",
            "selected": false
          },
          {
            "name": "jquery-ui.theme.min.css",
            "rel": "css\\jquery-ui.theme.min.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\jquery-ui.theme.min.css",
            "selected": false
          },
          {
            "name": "package.json",
            "rel": "css\\package.json",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\package.json",
            "selected": false
          },
          {
            "name": "style-old.css",
            "rel": "css\\style-old.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\style-old.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\index.html",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js",
        "selected": false,
        "commitHash": "83faea945ee8dab1d5b8a33229f02dada2300a27",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery-ui.min.js",
            "rel": "js\\jquery-ui.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\jquery-ui.min.js",
            "selected": false
          },
          {
            "name": "jquery.min.js",
            "rel": "js\\jquery.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\jquery.min.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "lodash.min.js",
            "rel": "js\\lodash.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\lodash.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\script.js",
            "selected": false
          },
          {
            "name": "ui-generators.js",
            "rel": "js\\ui-generators.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\83faea945ee8dab1d5b8a33229f02dada2300a27\\js\\ui-generators.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec",
    "hashAbbrev": "c31ac63",
    "tree": "070d0ee1af6116df4fb35e9a33dbddfa3336597a",
    "treeAbbrev": "070d0ee",
    "parents": ["5662a84c1a195903da28d92c636dd271ecb5de01"],
    "parentsAbbrev": ["5662a84"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523555715000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523555715000
    },
    "subject": "+ Added annyang to the project with basic ability to listen for sexy words and recognise them ~ Tidied up code, added some commenting etc",
    "body": "? Nothing particularly design-oriented happened on this step.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\.gitignore",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\README.md",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\audio",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\css",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec",
        "children": [
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\index.html",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\js",
        "selected": false,
        "commitHash": "c31ac63c0ae795e1bb25481d682d3c6941e6c2ec",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\c31ac63c0ae795e1bb25481d682d3c6941e6c2ec\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "5662a84c1a195903da28d92c636dd271ecb5de01",
    "hashAbbrev": "5662a84",
    "tree": "637154d35be3fdf696cf30476f8d8fd83a9bb16b",
    "treeAbbrev": "637154d",
    "parents": ["1c726ddfbac8ffdbe8e42415308bce177e91c0ed"],
    "parentsAbbrev": ["1c726dd"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523555180000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523555180000
    },
    "subject": "+ Added simple generation of upper and lower range + instructions + detection of successful number of strokes. + Added simple connection between sliding to correct next value and tone synthesis for feedback.",
    "body": "? Ran into the kind of obvious issue around precision. It's easy to slide beyond the upper and below the lower and still catch them 'successfully' making the whole thing kind of loose. On the one hand, that seems good in the sense that you should have some play in the system, but on the other hand it maybe makes any given motion less meaningful. It did feel kind of unnatural, though, to try to slide very specifically between a set range.\n\n? I wondered whether it might be better to have a visual indication of range rather than the numbers (and maybe even not having the pips and numbering on the slider) as a way of making it feel a little more \"naturalistic\"? But do you just end up in the same situation? And in a way aren't the numbers better for maintaining this idea of interface and computation as opposed to things that might be more overtly user experience-y or even organic?\n\n? The synthesis tone changes are quite satisfying and I can imagine that the base frequency going up with arousal will sound pretty appealing (possible even introducing harmonics now that I think about it?).",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "audio/tone.wav" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "A", "path_original": "js/flocking-all.min.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\.gitignore",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\README.md",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\audio",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\audio\\breath-mono.wav",
            "selected": false
          },
          {
            "name": "tone.wav",
            "rel": "audio\\tone.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\audio\\tone.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\css",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01",
        "children": [
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\index.html",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\js",
        "selected": false,
        "commitHash": "5662a84c1a195903da28d92c636dd271ecb5de01",
        "children": [
          {
            "name": "flocking-all.min.js",
            "rel": "js\\flocking-all.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\js\\flocking-all.min.js",
            "selected": false
          },
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\5662a84c1a195903da28d92c636dd271ecb5de01\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed",
    "hashAbbrev": "1c726dd",
    "tree": "3c5b0601a554fc401d7304c056f339bd91118f51",
    "treeAbbrev": "3c5b060",
    "parents": ["59481a9a95e104aa96bcd436cf26759cbcdb52c8"],
    "parentsAbbrev": ["59481a9"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523311279000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523311279000
    },
    "subject": "Added pip highlighting for ranges of values rather than precision",
    "body": "Allows for a sense of selecting elements more loosely which will allow for more expressive movement on the slider and feedback.",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\.gitignore",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\README.md",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\audio",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\audio\\breath-mono.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\css",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed",
        "children": [
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\index.html",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\js",
        "selected": false,
        "commitHash": "1c726ddfbac8ffdbe8e42415308bce177e91c0ed",
        "children": [
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\1c726ddfbac8ffdbe8e42415308bce177e91c0ed\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8",
    "hashAbbrev": "59481a9",
    "tree": "384336a63a4de439a06370e1bfec286ead670a02",
    "treeAbbrev": "384336a",
    "parents": ["b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0"],
    "parentsAbbrev": ["b9dab1c"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523297695000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1523297695000
    },
    "subject": "Added slider pips to represent numbers",
    "body": "In order to have precise instructions I added a jQuery plugin that added pips and numbers to a slider. This allows the interface to specifically talk about specific locations in a precise way (rather than \"top\" or \"bottom\" or more suggestive language like \"tip\" and \"base\")",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "css/jquery-ui-slider-pips.css" },
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "A", "path_original": "js/jquery-ui-slider-pips.js" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\.gitignore",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\README.md",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\audio",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\audio\\breath-mono.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\css",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8",
        "children": [
          {
            "name": "jquery-ui-slider-pips.css",
            "rel": "css\\jquery-ui-slider-pips.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\css\\jquery-ui-slider-pips.css",
            "selected": false
          },
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\index.html",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\js",
        "selected": false,
        "commitHash": "59481a9a95e104aa96bcd436cf26759cbcdb52c8",
        "children": [
          {
            "name": "jquery-ui-slider-pips.js",
            "rel": "js\\jquery-ui-slider-pips.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\js\\jquery-ui-slider-pips.js",
            "selected": false
          },
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\59481a9a95e104aa96bcd436cf26759cbcdb52c8\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0",
    "hashAbbrev": "b9dab1c",
    "tree": "87f84fd872ca4200ea0b2a7360aef38f57390fb9",
    "treeAbbrev": "87f84fd",
    "parents": ["db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1"],
    "parentsAbbrev": ["db90b59"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522706905000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522706905000
    },
    "subject": ".gitignore",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "A", "path_original": ".gitignore" }],
    "fileTree": [
      {
        "name": ".gitignore",
        "rel": ".gitignore",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\.gitignore",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0"
      },
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\README.md",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\audio",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\audio\\breath-mono.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\css",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0",
        "children": [
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\index.html",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\js",
        "selected": false,
        "commitHash": "b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0",
        "children": [
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\b9dab1c7179a200d89dbb1c988b70f6ea5acc3f0\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1",
    "hashAbbrev": "db90b59",
    "tree": "34022c9b6022a912402770253fdfec622f434f44",
    "treeAbbrev": "34022c9",
    "parents": ["a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6"],
    "parentsAbbrev": ["a2b4b75"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522700483000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522700483000
    },
    "subject": "Added twisting, gradient BG, knob colour animation, blinking, breathing; Changed pulse and shiver to CSS animation",
    "body": "Tidied up a few ideas by using CSS animations more for the various effects - at the very least leads to cleaner test code while I'm working this stuff out, though it's clearly less flexible programmatically if I want to tweak values based on what's happening in the game.\n\nCurrently I'm seeing myself as just adding a bunch of basic output modalities to start to get a sense of how it feels. Already wondering whether I'm straying too close to a human-like output form (notably the breathing and blinking). Also wondering if it's just too over the top right now.\n\nA good choice is always to strip back, so I may want to take that step again soon, but I do need to make sure I have a way of making the interaction actually feel like something. It still feels a little frictionless and a little undirected. It would make sense for the interface to have desires that can be communicated, rather than be a black box?\n\nIn which case literal instructions? \"Slide me between 3 and 5\"? That's very sexual immediately. Things to think about. Really need to write a journal entry about this at this point.",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "audio/breath-mono.wav" },
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "index.html" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\README.md",
        "selected": false,
        "commitHash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1"
      },
      {
        "name": "audio",
        "rel": "audio",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\audio",
        "selected": false,
        "commitHash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1",
        "children": [
          {
            "name": "breath-mono.wav",
            "rel": "audio\\breath-mono.wav",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\audio\\breath-mono.wav",
            "selected": false
          }
        ]
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\css",
        "selected": false,
        "commitHash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1",
        "children": [
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\index.html",
        "selected": false,
        "commitHash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\js",
        "selected": false,
        "commitHash": "db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1",
        "children": [
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\db90b59efca0b2a4c212f4ec3d2f7cda0d81abc1\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6",
    "hashAbbrev": "a2b4b75",
    "tree": "d0662aa7bfa158aeae464a8e5cdb703964f6b2ec",
    "treeAbbrev": "d0662aa",
    "parents": ["a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07"],
    "parentsAbbrev": ["a3a21bb"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522676320000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522676320000
    },
    "subject": "Added shivering and pulsing tests",
    "body": "Started the process of adding actual output modalities to see how they feel and to test key issues like whether you can still slide the slider if it's animating.\n\nBoth pulsing and shivering look pretty effective (and work with sliding).",
    "notes": "",
    "stats": [
      { "operation": "M", "path_original": "css/style.css" },
      { "operation": "M", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\README.md",
        "selected": false,
        "commitHash": "a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6"
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\css",
        "selected": false,
        "commitHash": "a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6",
        "children": [
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\index.html",
        "selected": false,
        "commitHash": "a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\js",
        "selected": false,
        "commitHash": "a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6",
        "children": [
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a2b4b756d95dbdbf20abb6d12990e9cfb973b0a6\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07",
    "hashAbbrev": "a3a21bb",
    "tree": "fe32f80eb72a764cf06879e41ff9b17b6c13718c",
    "treeAbbrev": "fe32f80",
    "parents": ["6f1c07270e2bd4533ff9b25f85ef70bd0cf91196"],
    "parentsAbbrev": ["6f1c072"],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522265696000
    },
    "committer": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522265696000
    },
    "subject": "Initial commit",
    "body": "A basic working jQuery UI slider with CSS styled to look innocuous.",
    "notes": "",
    "stats": [
      { "operation": "A", "path_original": "css/style.css" },
      { "operation": "A", "path_original": "index.html" },
      { "operation": "A", "path_original": "js/jquery.ui.touch-punch.min.js" },
      { "operation": "A", "path_original": "js/script.js" }
    ],
    "fileTree": [
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\README.md",
        "selected": false,
        "commitHash": "a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07"
      },
      {
        "name": "css",
        "rel": "css",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\css",
        "selected": false,
        "commitHash": "a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07",
        "children": [
          {
            "name": "style.css",
            "rel": "css\\style.css",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\css\\style.css",
            "selected": false
          }
        ]
      },
      {
        "name": "index.html",
        "rel": "index.html",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\index.html",
        "selected": false,
        "commitHash": "a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07"
      },
      {
        "name": "js",
        "rel": "js",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\js",
        "selected": false,
        "commitHash": "a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07",
        "children": [
          {
            "name": "jquery.ui.touch-punch.min.js",
            "rel": "js\\jquery.ui.touch-punch.min.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\js\\jquery.ui.touch-punch.min.js",
            "selected": false
          },
          {
            "name": "script.js",
            "rel": "js\\script.js",
            "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\a3a21bbb1df4b43ad1b20f29acb2401e1bb42d07\\js\\script.js",
            "selected": false
          }
        ]
      }
    ]
  },
  {
    "refs": [],
    "hash": "6f1c07270e2bd4533ff9b25f85ef70bd0cf91196",
    "hashAbbrev": "6f1c072",
    "tree": "2928bdfd48e5025d9bf6f8052f9b83a1450059e1",
    "treeAbbrev": "2928bdf",
    "parents": [],
    "parentsAbbrev": [],
    "author": {
      "name": "Pippin Barr",
      "email": "pippin.barr@gmail.com",
      "timestamp": 1522265597000
    },
    "committer": {
      "name": "GitHub",
      "email": "noreply@github.com",
      "timestamp": 1522265597000
    },
    "subject": "Initial commit",
    "body": "",
    "notes": "",
    "stats": [{ "operation": "A", "path_original": "README.md" }],
    "fileTree": [
      {
        "name": "README.md",
        "rel": "README.md",
        "abs": "C:\\Users\\enric\\AppData\\Local\\Temp\\repo-to-qda\\gitData\\pippinbarr--itisasifyouweremakinglove\\commits\\6f1c07270e2bd4533ff9b25f85ef70bd0cf91196\\README.md",
        "selected": false,
        "commitHash": "6f1c07270e2bd4533ff9b25f85ef70bd0cf91196"
      }
    ]
  }
]
